<?php
// Environment Modes
const MODE_STARTUP			= "startup";    // Startup mode to set configuration by auto config Wizard
const MODE_NORMAL			= "normal";     // Normal mode to set configuration without auto config Wizard
?>