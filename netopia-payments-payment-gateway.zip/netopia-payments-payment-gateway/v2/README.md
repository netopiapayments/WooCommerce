# NETOPIA Payments Plugin
## About Plugin
This plugin is work for API v1

## Features
    - Make Payment base on API v2
    - Has configuration wizard
    - is able to configure without wizard as well
    - has refound

## Problems 
    - Payment page has error and not return to website