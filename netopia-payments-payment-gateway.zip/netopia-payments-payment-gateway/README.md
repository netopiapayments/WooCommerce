# NETOPIA Payments Plugin
## About Plugin
The current wordpress plugin is a payment gateway base on NETOPIA Payments API version 2

This plugin has a auto configuration, to configure the plugin configuration

